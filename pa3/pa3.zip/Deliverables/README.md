./multilookup 1 1 results.txt serviced.txt names1.txt names2.txt names3.txt names4.txt names5.txt 
