pa2_driver.c has all of the module code. testapp.c has all of the test program code.

I have been able to get the module to work outside of the testapp, but I'm not sure why it isn't working in the testapp. Seek also does not seem to work, but I don't really understand how to test it.
